/**
 * Created by meihuabing on 2017/8/22.
 */
var gulp = require('gulp');
var browserify = require('gulp-browserify');
var watch = require('gulp-watch');
/**
 * 服务器功能,自动刷新
 */
var connect = require('gulp-connect');//livereload
/**
 * 代码转换
 * 转换成标准的css js文件
 */
var sass = require('gulp-sass');
/**
 * 代码压缩
 */
var uglify = require('gulp-uglify');
var minCSS = require('gulp-clean-css');
var htmlmin = require('gulp-htmlmin');


gulp.task('uglify',function () {
    return gulp.src('./js-src/main.js')
        .pipe(browserify())
        .pipe(uglify())
        .pipe(gulp.dest('./dest'));
});

gulp.task('sass',function () {
    return gulp.src('./cssfile/*.scss')
        .pipe(sass())
        .pipe(gulp.dest('./dest/cssfile/'))
});

gulp.task('mycss',['sass'],function () {
    return gulp.src('./dest/*.css')
        .pipe(minCSS())
        .pipe(gulp.dest('./destcssfile/'))
});


/**
 * 下面试文件监视相关
 */
gulp.task('html', function () {
    var options= {
        removeComments: true, //清除HTML注释
        collapseWhitespace: true, //压缩HTML
        minfyJS: true,//压缩JS
        minfyCss: true//压缩CSS
    };

    gulp.src('./index.html')
        .pipe(htmlmin(options))
        .pipe(gulp.dest('./dest'))
        .pipe(connect.reload());
});


//定义livereload任务
gulp.task('connect', function () {
    connect.server({
        livereload: true
    });
});

// 监控文件改变
gulp.task('watch',function(){
    // .pipe(watch('./sass-src/*.scss');
    gulp.watch('./cssfile/*.scss',['sass']);
    gulp.watch('./index.html',['html']);
});


gulp.task('default',['sass','watch'],function () {
    console.log("gulp ok")
});



// gulp.task('default',['mycss','uglify','html','watch','connect'],function () {
//     console.log("gulp ok")
// });
