//支持的统计工具平台
window.platform = [{
		"name": "_czc",
		"id": "1261272165"
	}, //name,统计平台名称；id：统计平台id
	{
		"name": "_hmt",
		"id": "ee8ef5fbc89d7ddf4b05aea86fe78bc0"
	}
];
window.h6app_shareConfig = {
	'shareData': {
		title: '中国民营企业500强名单',
		desc: '中国民营企业500强名单',
		imgUrl: '',
		link: window.location.href
	},
	'timeLineTitle': '中国民营企业500强名单', //选填，朋友圈标题，未填写将会取值shareData.title 
	'timeLineImgUrl': '', //选填，朋友圈图⽚信息，未填写将会取值shareData.imgUrl
	success: function() { //分享成功回调
		alert('分享成功');
	},
	cancel: function() { //分享取消回调
		alert('取消分享');
	},
	fromGroup: "group", //选填，统计来源群组名称，默认为 来⾃微信群
	fromSingle: "", //选填，统计来源好友名称，默认为 来⾃好友
	fromTimline: "", //选填，统计来源空间名称，默认为 来⾃朋友圈
	toFriend: "", //选填，统计分享到好友和群组名称，默认为 好友和群组
	toTimeLine: "", //选填，统计分享到QQ空间名称，默认为 朋友圈
};