/**
 * Created by meihuabing on 2017/8/23.
 */
var swiper1; 
var swiper2;
var swiper3; 

$(document).ready(function(){

    var $find_rank = $('.fristPage #find_rank');//找名次
    var $find_area = $('.fristPage #find_area');//找地区
    var $btn_true = $('.fristPage #btn_true');//确定
    var $btn_clear = $('.fristPage #btn_clear');//清除

    var $searchbtn = $('.secondPage #searchbtn');//查找

    var $ic_back = $('.fivePage #ic_back');//返回
    var $btn_good2 = $('.fivePage #btn_good2');//点赞
    var $btn_share_friend2 = $('.fivePage #btn_share_friend2');//点赞

    var $close_button = $('.sixPage #close_button');//关闭页面 六


    //页面0  找名次
    $find_rank.click(function (e) {
        showPages(1);
    });

    //页面0  找地区
    $find_area.click(function (e) {
        showPages(2);
    });


    //页面0  确认
    $btn_true.click(function (e) {
        showPages(4);
    });

    //页面0  清除
    $btn_clear.click(function (e) {
    	swiper1.slideTo(0, 50, false);//切换到第一个slide，速度为1秒
    	swiper2.slideTo(0, 50, false);//切换到第一个slide，速度为1秒
        swiper3.slideTo(1, 50, false);//切换到第一个slide，速度为1秒
    });


    //页面1  跳转
    var $companies1 = $('.secondPage ul li');//查找页面跳转
    $companies1.each(function (index,obj) {
        // console.log(obj);
        $(this).click(function (e) {
            console.log($(this).attr('title'))
            showPages(4)
        })
    });


    //页面2 搜索页面跳转
    var $companies2 = $('.threePage ul li');//查找页面跳转
    $companies2.each(function (index,obj) {
        // console.log(obj);
        $(this).click(function (e) {
            console.log($(this).attr('title'))
            showPages(4)
        })
    });

    //页面4 王者荣耀档案袋返回操作
    $ic_back.click(function (e) {
        console.log("王者荣耀档案袋返回操作");
        showPages(2)
    });

    //页面五点赞
    $btn_good2.click(function (e) {
        alert("您的openid为:" + window.h6app_userInfo.openid);

        $.ajax({
            url:'/admin/getNews',
            type:'get',
            data:{  openid:window.h6app_userInfo.openid,
                    sign:window.h6app_userInfo.sign,
                    voteId:'1'},
            datatype:'json',
            success:function (data) {
                console.log(data)
                alert(data)
                // data.forEach(function (item,index,array) {
                //     var $tdid = $('<td></td>').html(item.id);
                //     var $tdtype = $('<td></td>').html(item.newstype);
                //     var $tdtitle = $('<td></td>').html(item.newstitle);
                //     var $tdimg = $('<td></td>').html(item.newsimg);
                //     var $tdsrc = $('<td></td>').html(item.newssrc);
                //     var $tdtime = $('<td></td>').html(moment(item.newstime).format('MMMM Do YYYY, h:mm:ss'));
                //     var $tdctrl = $('<td></td>');
                //     var $btnupdata = $('<button></button>').addClass('btn btn-primary btn-xs').html('修改');
                //     var $btndelect = $('<button></button>').addClass('btn btn-danger btn-xs').html('删除');
                //     $tdctrl.append($btnupdata,$btndelect);
                //     var $tRow = $('<tr></tr>');
                //     $tRow.append($tdid,$tdtype,$tdtitle,$tdimg,$tdsrc,$tdtime,$tdctrl);
                //     $newstable.append($tRow);
                // })
            },
            error:function (error) {
                console.log( error)
                alert(error)
            }
        })






    });

    //页面五分享
    $btn_share_friend2.click(function (e) {
        console.log("分享");
        showPages(5)
    });


    //页面六 关闭
    $close_button.click(function (e) {
        console.log("关闭");
        showPages(4)
    });
    
    //锁-三个滑动配置
    swiper1 = new Swiper('#swiper1', {
		slidesPerView: 3,
		direction: 'vertical',
		paginationClickable: true,
		onSlideChangeEnd: function(swiper){
			changeSlide();
      }
	});


    //找地区页面选地区操作
    var $province_list = $('.threePage .province_list');
    $province_list.each(function (index,obj) {
        $(this).click(function (e) {
            clearAreaSelectStyle();
            $(this).addClass('areaSelectStyle');
            console.log($(this).attr('title'))
        })
    });

    //找地区页面选省份操作
    var $area_list = $('.threePage .area_list');
    $area_list.each(function (index,obj) {
        $(this).click(function (e) {
            clearAreaSelectStyle();
            $(this).addClass('areaSelectStyle');
            console.log($(this).attr('title'))
        })
    })

	
	swiper2 = new Swiper('#swiper2', {
		slidesPerView: 3,
		direction: 'vertical',
		paginationClickable: true,
		onSlideChangeEnd: function(swiper){
			changeSlide();
      }
	});
	
	swiper3 = new Swiper('#swiper3', {
		slidesPerView: 3,
		direction: 'vertical',
		paginationClickable: true,
		onSlideChangeEnd: function(swiper){
			changeSlide();
      }
	});
	//第三个锁默认显示0
	swiper3.slideTo(1, 50, false);//切换到第一个slide，速度为1秒

});

//控制锁的值在 001 - 500 范围
function changeSlide(){
	var index1 = $("#swiper1 .swiper-slide-active").html() ;
	var index2 = $("#swiper2 .swiper-slide-active").html() ;
	var index3 = $("#swiper3 .swiper-slide-active").html() ;
	if(index1 == 5){
		swiper2.slideTo(0, 50, false);//切换到第一个slide，速度为1秒
		swiper3.slideTo(0, 50, false);//切换到第一个slide，速度为1秒
	}
	if(index1 == 0 && index2 == 0){
		if(index3 == 0){
			swiper3.slideTo(1, 50, false);//切换到第一个slide，速度为1秒
		}
	}
}

// 页面跳转
function showPages(indexPage) {
    var $pages = $('.pages');
    console.log($pages)
    $pages.each(function (index,item) {
        $(this).removeClass('showDiv');
        $(this).removeClass('hiddenDiv');
        if (indexPage == index){
            $(this).addClass('showDiv')
        } else {
            $(this).addClass('hiddenDiv')
        }
    });
    
    if(4 == indexPage){
    	//先删掉之前的图片，再截屏
		$("#shotPage").find(".shotImg").remove();
    	screenshots();
    }
}


//清楚地区选择样式
function clearAreaSelectStyle() {
    var $province_list = $('.threePage .province_list');
    var $area_list = $('.threePage .area_list');

    $province_list.each(function () {
        $(this).removeClass("areaSelectStyle");
    });

    $area_list.each(function () {
        $(this).removeClass("areaSelectStyle");
    });
}


//截屏当前页面
function screenshots() {
	setTimeout(function() {
		var canvas = document.querySelector("canvas");
		var context = canvas.getContext("2d");
		var backingStore = context.backingStorePixelRatio ||
			context.webkitBackingStorePixelRatio ||
			context.mozBackingStorePixelRatio ||
			context.msBackingStorePixelRatio ||
			context.oBackingStorePixelRatio ||
			context.backingStorePixelRatio ||
			1;
		var radio = (window.devicePixelRatio || 1) / backingStore;
		canvas.width = document.body.clientWidth * radio;
		canvas.height = document.body.clientHeight * radio;
		context.scale(radio, radio);
		html2canvas(document.getElementById('shotPage'), {
			//allowTaint: true,
			useCORS: true,
			canvas: canvas,
			onrendered: function(canvas) {
				canvas.style.width = document.body.clientWidth + 'px';
				canvas.style.height = document.body.clientHeight + 'px';

				var dataUrl = canvas.toDataURL();
				var newImg = document.createElement("img");
				newImg.className = "shotImg" ;
				$(newImg).css({
					"position": "absolute",
					"top": "0px",
					"z-index": "100"
				});
				newImg.src = dataUrl;
				newImg.style.width = '100%';
				newImg.style.opacity = "0.01";
				document.getElementById('shotPage').appendChild(newImg);
				$("canvas").hide();
				
				console.log("截屏成功");
			}
		});
	}, 1000);
}